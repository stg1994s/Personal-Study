install.packages(c("alphahull", "conicfit", "cwhmisc", "doParallel", "fit.
models", "foreach", "igraph", "iterators", "MASS", "mco", "mesheR", 
                   "Morpho", "optimx", "parallel", "plotrix", "png", "pracma", "rgl", 
                   "robust", "robustbase", "rrcov", "Rvcg", "SDMTools", "shiny", "sp"))

                 
                 
